"use client";

import { ConnectButton } from "@mysten/dapp-kit";

export default function Navbar() {
  return (
    <header className="navbar">

      <div className="container navbar-inner">

        <div className="brand">

          <div className="brand-logo">
            ✦
          </div>

          <div>
            <h3>WST-MEMORY</h3>

            <p>
              WAVE SYNAPTIC TRANSFER
            </p>
          </div>

        </div>

        <nav className="nav-links">

  <a href="/">
    Home
  </a>

  <a href="/#workflow">
    How It Works
  </a>

  <a href="/#features">
    Features
  </a>

  <a href="/dashboard">
    Dashboard
  </a>

  <a href="/dashboard#architecture">
    Architecture
  </a>

  <a href="/dashboard#future">
    Future
  </a>

</nav>

        {/* REAL SUI WALLET */}
        <div className="wallet-wrap">
          <ConnectButton />
        </div>

      </div>

    </header>
  );
}